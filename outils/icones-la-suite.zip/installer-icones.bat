@echo off
chcp 65001 >nul
echo Installation des icones de La Suite...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0icones-la-suite.ps1" -Install
echo.
echo Termine. Tu peux fermer cette fenetre.
pause
